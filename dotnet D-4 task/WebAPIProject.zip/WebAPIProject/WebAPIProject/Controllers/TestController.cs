﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using WebAPIProject.Models;

namespace WebAPIProject.Controllers
{
    [ApiController]
    //[Route("api/[controller]")]
    public class TestController : ControllerBase
    {
        private List<Employee> employees = new List<Employee>()
        {
            new Employee()
            {
                Id = 1,
                Name = "Akhil Kukadiya"
            },
            new Employee()
            {
                Id=2,
                Name = "ram rotalya"
            },
            new Employee()
            {
                Id=3,
                Name = "ravi tank"
            },
            new Employee()
            {
                Id=4,
                Name = "dhano dhola"
            }
        };

        [HttpGet]
        [Route("api/[controller]/add")]
        public IActionResult Add([FromQuery]int first, [FromQuery]int second)
        {
            return Ok(first + second);
        }

        [HttpPost]
        [Route("api/[controller]/mul")]
        public IActionResult Multiply([FromForm]int first,[FromForm]int second)
        {
            return Ok(first * second);
        }


        [HttpPut]
        [Route("api/[controller]/sub")]
        public IActionResult Subtract([FromForm] int first, [FromForm] int second)
        {
            return Ok(first-second);
        }

        [HttpGet]
        [Route("api/[controller]/employee")]
        public IActionResult getData()
        {
            return Ok(employees);
        }
    }
}
