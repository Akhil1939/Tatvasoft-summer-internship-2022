﻿using System;

namespace BookStore.Models
{
    public class Class1
    {
    }
}
